# LINKED
## LIN🔗KED is a redesign &amp; clone website of ceipal.com
### 🎯 Key Responsibilities: It's focuses on providing comprehensive talent acquisition solutions.
## 💌 Tech Stack : HTML - CSS - JS 
## ✨ Design - Figma (Link - https://www.figma.com/file/QaCXPpetsW1y9lNxW2iOXz/Lin%F0%9F%94%97ked?type=design&node-id=0%3A1&mode=design&t=9VULXZjkNFeBvjLI-1 )
#### & all set 👍🏻  

![Linked](https://github.com/codeaashu/LINKED/assets/130897584/9c06a3ec-b721-4b46-8e82-2e276c9f5801)
