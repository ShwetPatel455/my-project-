
///////for each/////////////

// const coading =["js","java","html","csss"]

// coading.forEach( function (item) {
//     console.log(item);

// })

// coading.forEach( (item) => {
//     console.log(item);

// })


// function printMe(item){
//     console.log(item);

// }

// coading.forEach(printMe)

// coading.forEach((item,index,arr) => {
//     console.log(item,index,arr);

// })

// const myNum = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
// const newNums = myNum.filter((num) => {
//     return num > 4
// })


// const  newNums =[]

// newNums.forEach((num) => {
//     if (num >4){
//         newNums.push(num)
//     }

// });
// console.log(newNums);

// const myNumers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

// const newNums = myNumers.map((num) => num + 10)
// const newNumber = myNumers.map((num) => num - 10)
// const newNumbers = myNumers.map((num) => num * 10)
// const newNum = myNumers.map((num) => num % 10)
// const newNumnew = myNumers.map((num) => num / 10)

// console.log(newNums,newNumber,newNumbers,newNum,newNumnew);

// console.log(newNums);
// console.log(newNumber);
// console.log(newNumbers);
// console.log(newNum);
// console.log(newNumnew);


// const myNums = [1, 2, 3]
// const myTotal = myNums.reduce(function (acc, currval) {
//     console.log(`acc ${acc} and currval:${currval}`);

//     return acc + currval
// }, 0)

// const myNums = [1, 2, 3, 6, 8, 9]
// const myTotal = myNums.reduce((acc, curr) => acc + curr, 0)
// console.log(myTotal);

const shoppingcard = [
    {
        itemname: "js course",
        price: 1000
    },

    {
        itemname: "java",
        price: 456
    },

    {
        itemname: "Data science",
        price: 999

    },

    {
        itemname: "Python",
        price: 1452
    }
]

const pricetobook = shoppingcard.reduce((acc, item) => acc + item.price, 0)

console.log(pricetobook);


