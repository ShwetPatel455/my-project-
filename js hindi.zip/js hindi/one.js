/// if statement /////////////

//  < , > , <= , >= , == , != , === ,!==

//  const isUserloggedIn = true
//  const temperature =41

// if (temperature < 40){
// console.log("less than 50");

// }else{
// console.log("temperature is greater than 50");

// }





// if (false){

// }

// const score =200

// if (score > 100){
//     var power ="fly"
//     console.log(`user power: ${power}`);

// }

// console.log(`user power:${power}`);

const balance = 1000
// if (balance > 500) console.log("test");


// if (balance < 500) {
//     console.log("less than");

// } else if (balance < 750) {

// } else if (balance < 900) {
//     console.log("less then 900");

// } else {
//     console.log("less than 1200");

// }


const UserloggedIn = true
const debitCard = true
const loggedInFromGoogle = false
const loggedInFromEmail = true

if (UserloggedIn && debitCard) {
    console.log("allow to  buy course");

}

if(loggedInFromEmail || localStorage){
    console.log("user logged in");
    
}












