// const score = 400
// console.log(score)

// const balance = new Number (100)
// console.log(balance);

// console.log(balance.toString().length);
// console.log(balance.toFixed(1));

// const otherNumber = 23.8966

// console.log(otherNumber.toPrecision(5));

console.log(Math.random());
console.log((Math.random() * 10) + 1);
console.log(Math.floor(Math.random() * 10) + 1);

const min = 10
const max = 10

console.log(Math.floor(Math.random()*(max - min +1))+ min)