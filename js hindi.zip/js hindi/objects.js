// singleton

// object literals
// Object.create


// const mysym = Symbol ("key1")
// const JsUser = {
//     name: "Shwet",
//     [mysym]:"mykey1",
//     age: 20,
//     location: "Ahmedabad",
//     email: "Shwet@google.com",
//     isLoggedIn:false,
//     lastLoginDays:["Monday,Saturday"]

// }
// console.log(JsUser[mysym]);
// console.log(JsUser.email);
// console.log(JsUser.age);
// console.log(JsUser);

// JsUser.email = "Shwet@1224gogle.com"
// Object.freeze(JsUser)
// JsUser.email ="Shweypatel@google.com"
// console.log(JsUser);

// JsUser.greeting = function(){
//     console.log("hello js user");

// }
// console.log(JsUser.greeting());


const course = {
    coursename: "js is hindi",
    price: "999",
    courseInstructor: "Shwet"
}

const { courseInstructor } = course

console.log(courseInstructor);

const navbar = () => {

}
navbar(company = "Shwet")











