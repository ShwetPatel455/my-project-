// const tinderUser = new Object()
const tinderUser = {}

tinderUser.id = "123abc"
tinderUser.name = "Shwet"
tinderUser.isLoggedIn = false

// console.log(tinderUser);

// const regularUser = {
//     email: "Shwet@gmail.com",
//     fullname: {
//         userfullname: {
//             firstname: "Shwet",
//             lastname: "Patel"

//         }
//     }
// }

// console.log(regularUser.fullname.userfullname);

const obj1 = { 1: "A", 2: "B" }
const obj2 = { 3: "A", 4: "B" }

// const obj3 = {obj1,obj2}
// const obj3 = Object.assign({},obj1,obj2)

const obj3 = { ...obj1, ...obj2 }
// console.log(obj3);

const users = [
    {
        id: 1,
        email: "Shwet@google.com"
    },
    {
        id: 1,
        email: "Shwet@google.com"
    },
    {
        id: 1,
        email: "Shwet@google.com"
    },
]

users[1].email
// console.log(tinderUser);

// console.log(Object.keys(tinderUser));
// console.log(Object.values(tinderUser));
// console.log(Object.entries(tinderUser));

// console.log(tinderUser.hasOwnProperty('isLoggedIn'));


const course ={
    coursename: "Js hindi ",
    price:"999",
    courseinstructor:"Shwet"

}
const {courseinstructor} = course
// console.log(courseinstructor);

// const  navbar =({company}) => {

// } 

// navbar (company = "Shwet")


/// json //////////////

[
    {name:"shwet"},
    {price:"230"},
    {coursename:"Js in hindi"}
]














