// switch (key) {
//     case value:

//         break;

//     default:
//         break;
// }

const month = 2

switch (month) {
    case 1:
        console.log("january");

        break;
    case 2:
        console.log("febuary");

        break;
    case 3:
        console.log("march");

        break;

    default:
        console.log("default any month");

        break;
}














