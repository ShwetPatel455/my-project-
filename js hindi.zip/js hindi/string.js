const name = "shwet"
const repoCount = 50

console.log (name + repoCount + "value");

console.log(`Hello my name is ${name} and my repon count is ${repoCount}`);

const  gameName = new String(`Anjalipatel`)

console.log(gameName[0]);
console.log(gameName.__proto__);



console.log(gameName.length);
console.log(gameName.toUpperCase());
console.log(gameName.toLowerCase());


console.log(gameName.charAt(5));
console.log(gameName.indexOf('t'));












