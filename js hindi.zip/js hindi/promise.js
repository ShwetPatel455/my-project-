
const promiseOne = new Promise(function (resolve, reject) {
    // Do an async task
    // DB calls, cryptograph,network
    setTimeout(function () {
        console.log('async task is compeleted');
        resolve()

    }, 1000)
})

promiseOne.then(function () {
    console.log("promise consumed");

})

new Promise(function (resolve, reject) {
    setTimeout(function () {
        console.log("ssync task 2");
        resolve()
    }, 1000)

}).then(function () {
    console.log("async 2 resolve");

})


const promiseThree = new Promise(function (resolve, reject) {
    setTimeout(function () {
        resolve({ username: "Shwet", email: "shwetpatel@gamil.com" })
    }, 1000)
})
promiseThree.then(function (user) {
    console.log(user);

})

const promiseFour = new Promise(function (resolve, reject) {
    setTimeout(function () {
        let error = true
        if (!error) {
            resolve({ username: "Shwet", password: "1224" })
        } else {
            reject('ERROR:something went worng')
        }

    }, 1000)
})

promiseFour.then((user) => {
    console.log(user);
    return user.username

}).then((username) => {
    console.log(username);

}).catch(function (error) {
    console.log(error);

}).finally(() => console.log("the promise is either resolved rejected "));


const promiseFive = new Promise(function (resolve, reject) {
    setTimeout(function () {
        let error = true
        if (!error) {
            resolve({ username: "Anjali", password: "6624" })
        } else {
            reject('ERROR:JS went wrong')
        }

    }, 1000)
});

async function consumePromiseFive() {
    try {
        const response = await promiseFive
        console.log(response);
    } catch (error) {
        console.log(error);

    }


}

consumePromiseFive()

// async function getAllUsers() {
//     const response = await fetch('https://jsonplaceholder.typicode.com/users')
//     const data = response.json()
//     console.log(data);

// }


fetch('https://github.com/ShwetPatel455')
    .then((response) => {
        return response.json()
    })
    .then((data) => {
        console.log(data);

    })
    .catch((error) => console.log(error));












