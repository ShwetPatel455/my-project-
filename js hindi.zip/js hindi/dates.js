// let myDate = new Date()
// console.log(myDate.toString());
// console.log(myDate.toDateString());
// console.log(myDate.toLocaleString());
// console.log(typeof myDate);


// let myCreateDate = new Date(2025,5,23)
// console.log(myCreateDate.toDateString());

// let myTimeStamp = Date.now ()

// console.log(myTimeStamp);


let newDate = new Date()
console.log(newDate.getMonth() + 1);
console.log(newDate.getDay());


