
function sayMyName() {
    console.log("S");
    console.log("h");
    console.log("w");
    console.log("e");
    console.log("t");
    console.log("A");
    console.log("l");

}

// sayMyName()

function addTwoNumbers(number1, number2) {

    //    let result = number1 = number2
    //    console.log("Shwet patel");
    //    return result 
    return number1 + number2


}

const result = addTwoNumbers(3, 5)

// console.log("result:", result);
function loginUserMessage(username = "Anjali") {
    if (!username) {
        console.log("please enter a username");
        return

    }
    return `${username} just logged in `
}

// console.log(loginUserMessage("Shwet"));

function calculateCarPrice(...num1) {
    return num1
}

// console.log(calculateCarPrice(200,300,500));
const user = {
    username: "Shwet",
    price: 1200
}
function handleObject(anyobject) {
    console.log(`uUsername is ${anyobject.username} and price is ${anyobject.price}`);

}

// handleObject(user)

handleObject({
    username:"Says",
    price:1522
})

const myNewArray =[200,500,800,1200]

function returnsecondValue(getArray){
    return getArray[2]
}
console.log(returnsecondValue(myNewArray));




