let a = 500


if (true) {
    let a = 10
    const b = 20
    // console.log("INNER:", b);

}


// for (let i = 0; i < array.length; i++) {
//     const element = array[i];

// }
// console.log(a);
// console.log(b);
// console.log(c);

//////////////nested scopes/////////////////////
function one() {
    const username = "Shwet"
    function two() {
        const website = "youtube"
        console.log(username);

    }
    // console.log(website);

    two()
}

// one()

if (true) {
    const username = "anjali"
    if (username === "anjali") {
        const website = "youtube"
        // console.log(username + website);

    }
}

////////////////////interesting////////////////////////////

console.log(addone(5));


function addone(num) {
    return num + 1
}


const addTwo = function (num) {
    return num + 2
}

addTwo(5)
















