// alert("Hello")   //we are using nodejs, not browser

// console.log(3 + 3)

// console.log("Shwet")

// let name = "Shwet"
// let age = 20
// let isLoggedIn = false

// number => 2 to power 53
// bigint
// string => ""
// boolean => true/false
// null => standalone value 
// undefined =>
// symbol => unique 

// object 



// console.log(typeof "Shwet");




//primitive datatype

// 7 types: string, number, boolearn, null,undefiend,symbol,bigint

// const score = 100
// const scoreValue = 100.3

// const isLoggedIn = false
// const outsideTemp = null
// let userEmail;
// const id = Symbol ('123')
// const anotherId = symbol('123')

// console.log(id === anotherId);


//reference (non primitive)


// Arry, Object,Functions





// ++++++++++++++++++++++++++++++++++++++++
//stack (primitive), heap (non-primitive)

let myYoutubename = "shwetpatel"

let anothername = myYoutubename
anothername = "anjali patel"

console.log(myYoutubename);
console.log(anothername);

let userOne = {
    email: "patelshwet127@gamil.com",
    upi: "user@bl"

}

let userTwo = userOne
userTwo.email = "Anjalipatel127@gmail.com"

console.log(userOne.email);
console.log(userTwo.email);