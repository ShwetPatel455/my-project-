// attachEvent()
// jQuery - on



// document.getElementById('hello').onclick = function () {
//     alert("hello clicked in my button")
// }

// type, timestamp, defaultPrevented
// target, toElement, srcElement, currentTarget,clientX,clientY,screenY
// altKey,ctrlKey,shiftKey,KeyCode




document.getElementById('hello').addEventListener('click', function (e) {
    console.log("hello button clicked");

})

document.getElementById('google').addEventListener('click', function (e) {
    e.preventDefault();
    e.stopPropagation()
    console.log("google clicked");

})



// image ke per click kar ne per image remove ho jana chahi ye  niche example diya gaya hai 


// document.querySelector('#hell').addEventListener('click', function (e) {
//     console.log(e.target.parentNode);
//     if (e.target.tagName === 'IMG') {
//         console.log(e.target.id);
//         let removeIt = e.target.parentNode
//         removeIt.remove()

//     }


// })





