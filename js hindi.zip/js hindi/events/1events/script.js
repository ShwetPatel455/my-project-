
// setTimeout(function(){
//     console.log("Shwet");

// },2000)

const sayShwet = function () {
    console.log("Shwet");

}
const changeText = function () {
    document.querySelector('h1').innerHTML = "This is a best Series of a latest version"

}
const changeMe = setTimeout(changeText, 2000)

// document.querySelector('#stop').addEventListener('click', function () {
//     clearTimeout(changeMe)
//     console.log("STOPPED");

// })








