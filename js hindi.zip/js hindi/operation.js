////////// conversion aur operation////////////

// let score ="33"
// console.log (typeof score)
// console.log (typeof(score));

// let valueInNumber = Number(score);
// console.log (valuInNumber);

let isLoggedIn = "55"

let booleanIsLoggedIn = Boolean(isLoggedIn)
console.log(booleanIsLoggedIn);


// 1 => true; 0 =>False
// "" => false
// "shwet" => true
// "55" => true


let someNumber = 33
let strintNumber = (someNumber)
console.log(Number);




// ***********operation*******

let value = 3
let negValue = -value
// console.log(negValue);

// console.log(2+2);
// console.log(2-2);
// console.log(2%2);
// console.log(2*2);
// console.log(2**2);
// console.log(2/2);

let str1 = "shwet"
let str2 = "hello"

let str3 = str1 + str2
console.log(str3);

console.log("1" + 2);  //12
console.log(1 + "2");  //12
console.log(1 + 2 + "2"); //32
console.log(1 + 1 + 2 + "2"); //42