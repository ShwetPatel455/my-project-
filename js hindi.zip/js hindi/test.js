console.log("Shwet")
console.log("my name is patel shwet")