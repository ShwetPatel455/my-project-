const user = {
    username: "Shwet",
    price: 999,

    welcomeMessage: function () {
        console.log(`${this.username},Welcome to website`);

    }
}

// user.welcomeMessage()
// user.username = "sam"
// user.welcomeMessage()


// console.log(this);

// function chai() {
//     let username = "Shwet"
//     console.log(this.username);

// }

// chai()

const chai = () => {
    let username = "Shwet"
    console.log(this);

}

// chai()



// const addTwo = (num1, num2) => {
//     return num1 + num2
// }

// const addTwo = (num1, num2) => num1 + num2
// const addTwo = (num1, num2) => (num1 + num2)

const addTwo = (num1, num2) =>({username:"Shwet"})


console.log(addTwo(5, 8));























