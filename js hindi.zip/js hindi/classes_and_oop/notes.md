# javascript and classes

# oop(object oriented programming)


- collection of properties and methods
- toLowerCase

## why use oop

# parts of oop
Object literal

-  constructor function
- prototypes
- classes
- instances (new,this)

## 4 pillars
abtraction //  details hide har deta hai (ex:- fetch())

Encapsulation // wrapper kar deta hai 

Inheritance // 

Polymorphism // means bahurupi (eek methd multiple work kar deta hai)
