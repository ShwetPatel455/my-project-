
function SetUsername(username) {
    //complex DB calls
    this.username = username
    console.log("called");

}

function createUser(username, email, password) {
    SetUsername.call(this, username)

    this.email = email
    this.password = password
}

const code = new createUser("Shwet", "Shwet@mail.com", "123")
console.log(code);
// ES6

// class User {
//     constructor(username, email, password) {
//         this.username = username;
//         this.email = email;
//         this.password = password
//     }
//     encryptPassword() {
//         return `${this.password}abc`
//     }
//     changeUsername() {
//         return `${this.username.toUpperCase()}`
//     }
// }


// const create = new User("chai", "Create@gmail.com", "1224")
// console.log(create.encryptPassword());
// console.log(create.changeUsername());

// behind the  scene

function User(username, email, password) {
    this.username = username;
    this.email = email;
    this.password = password
}

User.prototype.encryptPassword=function(){
    return`${this.password}abc`
}
User.prototype.changeUsername=function(){
      return `${this.username.toUpperCase()}`
}

const tea=new User ("tea","tea@gmail.com","6624")

console.log(tea.encryptPassword());
console.log(tea.changeUsername());




















