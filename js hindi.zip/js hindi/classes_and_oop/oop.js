const user = {
    username: "shwet",
    loginCount: 8,
    signedn: true,

    getUserDetails: function () {
        console.log("Go to the user name and data ");

    }
}

// console.log(user);
// console.log(user.getUserDetails());

// const promiseOne = new Promise()
// const date = new Date()

function User(username, loginCount, isLoggedIn) {
    this.sername = username;
    this.loginCount = loginCount;
    this.isLoggedIn = isLoggedIn
    this.greeting = function () {
        console.log(`welcome${this.username}`);

    }
    return this
}

const userOne = new User("Shwet", 12, true)
const userTwo = new User("Shwet aur code")
console.log(userOne);
console.log(userTwo);
