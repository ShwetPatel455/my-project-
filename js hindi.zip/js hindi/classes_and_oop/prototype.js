
let myName="Shwet"

console.log(myName.length);




