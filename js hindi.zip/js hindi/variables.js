const accountId = 144553
let  accountEmail = "Shwet@google"
var accountPassword = "12345"
accountCity = "jaipur "


// acount = 2

accountEmail = "hc@hc.com"
accountPassword = 1224
accountCity ="ahmedabad"
let accountState;

console.log(accountId);



/*
prefer not to use var 
*/

console.table([accountEmail, accountId, accountPassword, accountCity, accountState]);